
// import { Component, OnInit } from '@angular/core';
// import { Http, } from '@angular/http';

// import {HttpErrorResponse, HttpHandler, HttpHeaderResponse, HttpInterceptor,
//   HttpProgressEvent, HttpRequest, HttpResponse, HttpSentEvent, HttpUserEvent, HttpEvent} from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { Router } from '@angular/router';
// import 'rxjs/add/operator/do';
// import { Observable } from 'rxjs/Observable';
// import { environment } from '../environments/environment';
// import { AuthService } from './auth.service';

// @Injectable()
// export class AppInterceptor implements HttpInterceptor {

//   constructor(private router: Router, private appService: AuthService) { }

//   intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//     let authReq = req;
//     console.log("we made it");
//     const APP_URL = "http://localhost:4200/"
//     const access_token = this.appService.getToken();
//     if (access_token) {
//       authReq = req.clone({
//         setHeaders: {
//           Authorization: `Token ${this.appService.getToken()}`
//         }
//       });
//       /** Remove below code once integrated with backend as single package */
//       authReq = authReq.clone({headers: authReq.headers.set('Access-Control-Allow-Origin', '*')});
//       authReq = authReq.clone({headers: authReq.headers.set('Access-Control-Allow-Origin', APP_URL)});
//     }
//     return next.handle(req);
//   }

// }


import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { AuthService } from './auth.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import { Router } from '@angular/router';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(public auth: AuthService, private myRoute: Router) {}

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.auth.getToken() !== null) {
      request = request.clone({
      setHeaders: {
          Authorization: `Token ${this.auth.getToken()}`
        }
      });
    }
    return next.handle(request).do((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
        // do stuff with response if you want
        // console.log("para ! intercepted the result");
      }
    }, (err: any) => {
      if (err instanceof HttpErrorResponse) {
        if (err.status === 401) {
          this.myRoute.navigate(['login']);
        }
      }
    });
  }
}
