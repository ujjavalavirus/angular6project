import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ShowDataComponent } from './show-data/show-data.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { LoginComponent } from './login/login.component';

import { AuthService } from './auth.service';     //login auth guard
import { AuthGuard } from './auth.guard';         //login auth guard


const appRoutes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'error', component: PagenotfoundComponent},
    { path: 'login', component: LoginComponent},
    // { path: 'home', component: ShowDataComponent, canActivate: [AuthGuard]}
    { path: 'home', component: ShowDataComponent}
];

@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes)
    ],
    exports: [
        RouterModule
    ]
})

export class AppRoutingModule {}
