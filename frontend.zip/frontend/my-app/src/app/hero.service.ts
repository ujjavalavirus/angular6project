import { Injectable } from '@angular/core';
import { Response, Http } from '@angular/http';
import { HttpClient, HttpHeaders  } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { throwError } from 'rxjs';
import { filter, map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class HeroService {
  baseurl: string = 'http://127.0.0.1:8000/';
  constructor(private htto: Http, private http: HttpClient) { }

  onError(res: Response) {
    const statusCode = res.status;
    const body = res.json();
    const error = {
      statusCode: statusCode,
      error: body.error
    };
    return throwError(error);
  }

  post(url, data) {
    let headers = new HttpHeaders();
    headers = headers.set('Content-Type', 'application/json; charset=utf-8');
    return this.http
      .post(this.baseurl + url, JSON.stringify(data), {headers: headers} )
      .pipe(map((res: Response) => res), catchError((res: Response) => this.onError(res)));

  }

  get(url) {
    return this.http.get(url)
    .pipe(map((res: Response) => res), catchError((res: Response) => this.onError(res)));
  }
}

// here we ares using HttpClient for making Http requests, which can also be made by using Http. So the difference lies in the usage
// since we need intercept our request for adding token and for several other things HttpClient is much used in Angular V6
// Http has been imported from '' and used in constructor by the variable htto, which is never used, but have kept to know the difference
