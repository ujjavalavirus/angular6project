import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { HeroService } from '../hero.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login_form;
  constructor(private form_var: FormBuilder,
    private myRoute: Router,
    private auth: AuthService,
    private heroService: HeroService) {
    this.login_form = form_var.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });
  }
  ngOnInit() {
    if (localStorage.getItem('LoggedInUser') === null) {
      this.myRoute.navigate(['login']);
    } else {
      this.myRoute.navigate(['home']);
    }
  }
  logon(form) {
    if (this.login_form.valid) {
      const valla = form.value;
      return this.heroService.post('api/login/', valla).subscribe((resp) => {
        this.auth.sendToken(resp['token']);
        this.myRoute.navigate(['home']);
      }, (error) => {
        console.log(error);
        alert(error.error);
      } );

    }
  }
}
