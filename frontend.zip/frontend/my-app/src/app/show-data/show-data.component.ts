import { Component, OnInit } from '@angular/core';
import { Http, } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { HeroService } from '../hero.service';

@Component({
  selector: 'app-show-data',
  templateUrl: './show-data.component.html',
  styleUrls: ['./show-data.component.css']
})
export class ShowDataComponent implements OnInit {
  data: any;
  private req: any;
  baseurl: string = 'http://127.0.0.1:8000/';
  url: string = '';
  fname: string = '';
  lname: string = '';
  id: number;
  activator: boolean;

  constructor(private http: HttpClient, private heroService: HeroService ) { }

  ngOnInit() {
  this.activator = false;
  this.url += 'getData/';
  this.req = this.heroService.get(this.baseurl + this.url).subscribe(data => {
      this.data = data;
  });
  }

  savemadu(form) {
    const valla = form.value;
    return this.heroService.post('getData/', valla).subscribe((resp) => {
      console.log(resp);
    }, (error) => {
      console.log(error);
      alert(error.error);
    } );
  }

  onSelect(hero: string): void {
    this.fname = hero['band_group'].band_color;
    this.lname = hero['band_group'].band_group_name;
    this.id = hero['usn'];
    this.activator = true;
  }

  ngOnDestroy() {
    this.req.unsubscribe();
  }

  fetchmore() {
    this.url = this.baseurl + `getuserdetails/${this.id}`;
    return this.heroService.get(this.url).subscribe((resp) => {
      console.log(resp);
    }, (error) => {
      console.log(error);
    });
  }

}
